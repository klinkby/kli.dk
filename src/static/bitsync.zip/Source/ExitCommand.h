#pragma once
#include "ICommand.h"

namespace BITSync
{
	using namespace System;
	using namespace System::Windows::Forms;

	ref class ExitCommand : ICommand {
	public:
		virtual void Execute()
		{
			Application::Exit();
		}
	};
}