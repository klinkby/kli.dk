#pragma once
#include "ICommandExecuter.h"
#include "SynchronizeOneCommand.h"

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections::Generic;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;
using namespace System::Threading;


namespace BITSync {

	/// <summary>
	/// Summary for SynchronizeForm
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	ref class SynchronizeForm : public System::Windows::Forms::Form
	{
	private:
		ICommandExecuter^ _executer;
	public:
		SynchronizeForm(ICommandExecuter^ executer, FileRef^ fileRef) 
			: _executer(executer), _thread(nullptr), _fileRef(fileRef)
		{
			InitializeComponent();
		}

	private:
		
		FileRef^ _fileRef;
		Thread^ _thread;

		 //void CreateDirs(String^ basePath, System::Collections::Generic::IEnumerable<String^>^ dirs)
		 //{
			//for each(String^ dir in dirs)
			//{
			//	String^ basedDir = System::IO::Path::Combine(basePath, dir);
			//	System::IO::Directory::CreateDirectory(basedDir);
			//}
		 //}

		 //void CreateDownloadJob(FileRef^ basePaths, System::Collections::Generic::IEnumerable<String^>^ files)
		 //{
			//List<FileRef^> filesRefs;
			//int i = 0;
			//for each(String^ file in files)
			//{
			//	String^ localPath = System::IO::Path::Combine(basePaths->LocalFile, file);
			//	String^ remotePath = System::IO::Path::Combine(basePaths->RemoteFile, file);
			//	Uri^ remoteUri = gcnew Uri(gcnew Uri("file://"), gcnew Uri(remotePath));
			//	filesRefs.Add(gcnew FileRef(localPath, remoteUri->AbsoluteUri));
			//}
			////bitService->CreateJob(DateTime::Now.ToString(), filesRefs.ToArray());
		 //}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~SynchronizeForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  cmdCancel;
	protected: 

	private: System::Windows::Forms::ListBox^  listBox1;

	private: System::Windows::Forms::Button^  cmdOK;
	protected: 

	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->cmdCancel = (gcnew System::Windows::Forms::Button());
			this->listBox1 = (gcnew System::Windows::Forms::ListBox());
			this->cmdOK = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// cmdCancel
			// 
			this->cmdCancel->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Right));
			this->cmdCancel->CausesValidation = false;
			this->cmdCancel->DialogResult = System::Windows::Forms::DialogResult::Cancel;
			this->cmdCancel->Location = System::Drawing::Point(197, 138);
			this->cmdCancel->Name = L"cmdCancel";
			this->cmdCancel->Size = System::Drawing::Size(75, 23);
			this->cmdCancel->TabIndex = 3;
			this->cmdCancel->Text = L"&Cancel";
			this->cmdCancel->UseVisualStyleBackColor = true;
			// 
			// listBox1
			// 
			this->listBox1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom) 
				| System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->listBox1->FormattingEnabled = true;
			this->listBox1->Location = System::Drawing::Point(12, 9);
			this->listBox1->Name = L"listBox1";
			this->listBox1->SelectionMode = System::Windows::Forms::SelectionMode::None;
			this->listBox1->Size = System::Drawing::Size(260, 121);
			this->listBox1->TabIndex = 1;
			// 
			// cmdOK
			// 
			this->cmdOK->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Right));
			this->cmdOK->DialogResult = System::Windows::Forms::DialogResult::OK;
			this->cmdOK->Enabled = false;
			this->cmdOK->Location = System::Drawing::Point(116, 138);
			this->cmdOK->Name = L"cmdOK";
			this->cmdOK->Size = System::Drawing::Size(75, 23);
			this->cmdOK->TabIndex = 2;
			this->cmdOK->Text = L"&OK";
			this->cmdOK->UseVisualStyleBackColor = true;
			// 
			// SynchronizeForm
			// 
			this->AcceptButton = this->cmdOK;
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->CancelButton = this->cmdCancel;
			this->ClientSize = System::Drawing::Size(284, 173);
			this->Controls->Add(this->cmdOK);
			this->Controls->Add(this->listBox1);
			this->Controls->Add(this->cmdCancel);
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"SynchronizeForm";
			this->ShowInTaskbar = false;
			this->Text = L"Synchronize";
			this->Activated += gcnew System::EventHandler(this, &SynchronizeForm::SynchronizeForm_Activated);
			this->ResumeLayout(false);

		}
#pragma endregion
	private: 
		System::Void SynchronizeForm_Activated(System::Object^  sender, System::EventArgs^  e) {
			if (_thread == nullptr)
			{
				_thread = gcnew Thread(gcnew ParameterizedThreadStart(ThreadProc));
				_thread->IsBackground = true;
				_thread->Start(this);
			}
		 }


	 static void ThreadProc(Object^ state)
	 {
		SynchronizeOneCommand^ cmd = gcnew SynchronizeOneCommand();
		SynchronizeForm^ me = (SynchronizeForm^)state;
		cmd->File = me->_fileRef;
		me->_executer->Execute(cmd);
		delete cmd;
		//me->WriteLog("Reading local file structure...");
		//FileSet^ local = gcnew FileSet("c:\\temp");//.Synchronize();
		//me->WriteLog("Reading remote file structure...");
		//FileSet^ remote = gcnew FileSet("m:\\");
		//me->WriteLog("Ensure directory structure...");
		//System::Collections::Generic::IList<String^>^ dirs = local->GetDiffDirs(remote);
		//me->CreateDirs(local->BaseDir, dirs);
		//me->WriteLog(String::Format("{0} directories created.", dirs->Count));
		//me->WriteLog("Ensure file structure...");
		//System::Collections::Generic::IList<String^>^ files = local->GetDiffFiles(remote);
		//me->CreateDownloadJob(gcnew FileRef(local->BaseDir, remote->BaseDir), files);
		//me->WriteLog(String::Format("Downloading {0} files.", files->Count));
		//me->OperationCompleted();
	 }
};
}
