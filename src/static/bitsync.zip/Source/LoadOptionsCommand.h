#pragma once
#include "ICommand.h"
#include "Options.h"

namespace BITSync
{
	using namespace System;
	using namespace System::Runtime::InteropServices;

	ref class LoadOptionsCommand : ICommand {
	private:
		Options^ _options;
	public:
		property Options^ Settings
		{
			Options^ get() {
				return _options;
			}
		}

		virtual void Execute(SetStatusCallback^ setStatus)
		{
			HKEY hOutKey;
			if (RegCreateKeyExW(HKEY_CURRENT_USER, registryOptionsKey, 
				NULL, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS,
				NULL, &hOutKey, NULL) ==  ERROR_SUCCESS)
			{
				try {
					_options = gcnew Options(
						GetStringValue(hOutKey, L"IncludePattern", defIncludePattern),
						GetStringValue(hOutKey, L"ExcludePattern", defExcludePattern));
				}
				finally {
					RegCloseKey(hOutKey);			
				}
			}
		}

		static String^ GetStringValue(HKEY hKey, LPCWSTR szName, LPCWSTR szDefault)
		{
			const int keysize = 1024;
			LPWSTR lpValue = new WCHAR[keysize];
			try {
				DWORD lpcValue = keysize;
				if (RegGetValueW(hKey, NULL, szName, RRF_RT_REG_SZ, NULL, (PBYTE)lpValue, &lpcValue) 
					== ERROR_SUCCESS)
					return gcnew String(lpValue);
				else
					return gcnew String(szDefault);
			}
			finally {
				delete lpValue;
			}
		}
	};
}