#pragma once
#include "BITService.h"
#include "ListJobsCommand.h"
#include "ICommandExecuter.h"

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;

namespace BITSync {

	/// <summary>
	/// Summary for StatusForm
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	ref class StatusForm : public System::Windows::Forms::Form
	{
	private:
		ICommandExecuter^ _executer;
	public:
		StatusForm(ICommandExecuter^ executer) 
			: _executer(executer), _activated(false)
		{
			InitializeComponent();
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~StatusForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  cmdDelete;
	protected: 

	private: System::Windows::Forms::Button^  cmdClose;





	private: System::Windows::Forms::Button^  cmdResume;


	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::ListView^  listView2;
	private: System::Windows::Forms::ColumnHeader^  columnHeader6;


	private: System::Windows::Forms::ColumnHeader^  columnHeader9;
	private: System::Windows::Forms::ColumnHeader^  columnHeader10;
	private: System::Windows::Forms::SplitContainer^  splitContainer1;
	private: System::Windows::Forms::ListView^  listView1;
	private: System::Windows::Forms::ColumnHeader^  columnHeader1;
	private: System::Windows::Forms::ColumnHeader^  columnHeader2;
	private: System::Windows::Forms::ColumnHeader^  columnHeader3;
	private: System::Windows::Forms::ColumnHeader^  columnHeader4;
	private: System::Windows::Forms::ColumnHeader^  columnHeader5;
	private: System::Windows::Forms::Label^  label1;



	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->cmdDelete = (gcnew System::Windows::Forms::Button());
			this->cmdClose = (gcnew System::Windows::Forms::Button());
			this->cmdResume = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->listView2 = (gcnew System::Windows::Forms::ListView());
			this->columnHeader6 = (gcnew System::Windows::Forms::ColumnHeader());
			this->columnHeader9 = (gcnew System::Windows::Forms::ColumnHeader());
			this->columnHeader10 = (gcnew System::Windows::Forms::ColumnHeader());
			this->splitContainer1 = (gcnew System::Windows::Forms::SplitContainer());
			this->listView1 = (gcnew System::Windows::Forms::ListView());
			this->columnHeader1 = (gcnew System::Windows::Forms::ColumnHeader());
			this->columnHeader2 = (gcnew System::Windows::Forms::ColumnHeader());
			this->columnHeader3 = (gcnew System::Windows::Forms::ColumnHeader());
			this->columnHeader4 = (gcnew System::Windows::Forms::ColumnHeader());
			this->columnHeader5 = (gcnew System::Windows::Forms::ColumnHeader());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->splitContainer1->Panel1->SuspendLayout();
			this->splitContainer1->Panel2->SuspendLayout();
			this->splitContainer1->SuspendLayout();
			this->SuspendLayout();
			// 
			// cmdDelete
			// 
			this->cmdDelete->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Left));
			this->cmdDelete->Enabled = false;
			this->cmdDelete->Location = System::Drawing::Point(12, 184);
			this->cmdDelete->Name = L"cmdDelete";
			this->cmdDelete->Size = System::Drawing::Size(75, 23);
			this->cmdDelete->TabIndex = 4;
			this->cmdDelete->Text = L"&Delete";
			this->cmdDelete->UseVisualStyleBackColor = true;
			this->cmdDelete->Click += gcnew System::EventHandler(this, &StatusForm::cmdDelete_Click);
			// 
			// cmdClose
			// 
			this->cmdClose->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Right));
			this->cmdClose->CausesValidation = false;
			this->cmdClose->DialogResult = System::Windows::Forms::DialogResult::Cancel;
			this->cmdClose->Location = System::Drawing::Point(462, 184);
			this->cmdClose->Name = L"cmdClose";
			this->cmdClose->Size = System::Drawing::Size(75, 23);
			this->cmdClose->TabIndex = 5;
			this->cmdClose->Text = L"&Close";
			this->cmdClose->UseVisualStyleBackColor = true;
			// 
			// cmdResume
			// 
			this->cmdResume->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Left));
			this->cmdResume->Location = System::Drawing::Point(98, 184);
			this->cmdResume->Name = L"cmdResume";
			this->cmdResume->Size = System::Drawing::Size(75, 23);
			this->cmdResume->TabIndex = 8;
			this->cmdResume->Text = L"&Resume";
			this->cmdResume->UseVisualStyleBackColor = true;
			this->cmdResume->Click += gcnew System::EventHandler(this, &StatusForm::cmdResume_Click);
			// 
			// label2
			// 
			this->label2->Dock = System::Windows::Forms::DockStyle::Top;
			this->label2->Location = System::Drawing::Point(0, 0);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(198, 13);
			this->label2->TabIndex = 9;
			this->label2->Text = L"&Files";
			// 
			// listView2
			// 
			this->listView2->Columns->AddRange(gcnew cli::array< System::Windows::Forms::ColumnHeader^  >(3) {this->columnHeader6, this->columnHeader9, 
				this->columnHeader10});
			this->listView2->Dock = System::Windows::Forms::DockStyle::Fill;
			this->listView2->HeaderStyle = System::Windows::Forms::ColumnHeaderStyle::Nonclickable;
			this->listView2->Location = System::Drawing::Point(0, 13);
			this->listView2->Name = L"listView2";
			this->listView2->Size = System::Drawing::Size(198, 153);
			this->listView2->Sorting = System::Windows::Forms::SortOrder::Ascending;
			this->listView2->TabIndex = 7;
			this->listView2->UseCompatibleStateImageBehavior = false;
			this->listView2->View = System::Windows::Forms::View::Details;
			// 
			// columnHeader6
			// 
			this->columnHeader6->Text = L"Filename";
			// 
			// columnHeader9
			// 
			this->columnHeader9->Text = L"Progress";
			this->columnHeader9->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			// 
			// columnHeader10
			// 
			this->columnHeader10->Text = L"Size";
			this->columnHeader10->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			// 
			// splitContainer1
			// 
			this->splitContainer1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom) 
				| System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->splitContainer1->Location = System::Drawing::Point(12, 12);
			this->splitContainer1->Name = L"splitContainer1";
			// 
			// splitContainer1.Panel1
			// 
			this->splitContainer1->Panel1->Controls->Add(this->listView1);
			this->splitContainer1->Panel1->Controls->Add(this->label1);
			// 
			// splitContainer1.Panel2
			// 
			this->splitContainer1->Panel2->Controls->Add(this->listView2);
			this->splitContainer1->Panel2->Controls->Add(this->label2);
			this->splitContainer1->Size = System::Drawing::Size(524, 166);
			this->splitContainer1->SplitterDistance = 322;
			this->splitContainer1->TabIndex = 10;
			// 
			// listView1
			// 
			this->listView1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::ColumnHeader^  >(5) {this->columnHeader1, this->columnHeader2, 
				this->columnHeader3, this->columnHeader4, this->columnHeader5});
			this->listView1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->listView1->HeaderStyle = System::Windows::Forms::ColumnHeaderStyle::Nonclickable;
			this->listView1->HideSelection = false;
			this->listView1->Location = System::Drawing::Point(0, 13);
			this->listView1->Name = L"listView1";
			this->listView1->Size = System::Drawing::Size(322, 153);
			this->listView1->TabIndex = 7;
			this->listView1->UseCompatibleStateImageBehavior = false;
			this->listView1->View = System::Windows::Forms::View::Details;
			this->listView1->SelectedIndexChanged += gcnew System::EventHandler(this, &StatusForm::listBox1_SelectedIndexChanged);
			// 
			// columnHeader1
			// 
			this->columnHeader1->Text = L"Title";
			// 
			// columnHeader2
			// 
			this->columnHeader2->Text = L"State";
			// 
			// columnHeader3
			// 
			this->columnHeader3->Text = L"Files";
			this->columnHeader3->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			// 
			// columnHeader4
			// 
			this->columnHeader4->Text = L"Progress";
			this->columnHeader4->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			// 
			// columnHeader5
			// 
			this->columnHeader5->Text = L"Size";
			this->columnHeader5->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			// 
			// label1
			// 
			this->label1->Dock = System::Windows::Forms::DockStyle::Top;
			this->label1->Location = System::Drawing::Point(0, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(322, 13);
			this->label1->TabIndex = 9;
			this->label1->Text = L"&Jobs";
			// 
			// StatusForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->CancelButton = this->cmdClose;
			this->ClientSize = System::Drawing::Size(549, 219);
			this->Controls->Add(this->splitContainer1);
			this->Controls->Add(this->cmdResume);
			this->Controls->Add(this->cmdClose);
			this->Controls->Add(this->cmdDelete);
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->MinimumSize = System::Drawing::Size(284, 194);
			this->Name = L"StatusForm";
			this->ShowInTaskbar = false;
			this->Text = L"BITS Service Status";
			this->FormClosed += gcnew System::Windows::Forms::FormClosedEventHandler(this, &StatusForm::StatusForm_FormClosed);
			this->splitContainer1->Panel1->ResumeLayout(false);
			this->splitContainer1->Panel2->ResumeLayout(false);
			this->splitContainer1->ResumeLayout(false);
			this->ResumeLayout(false);

		}
#pragma endregion

	protected:
		virtual void OnActivated(System::EventArgs ^e) override
		{
			if (!_activated)
				RefreshView1();
			_activated = true;
			__super::OnActivated(e);
		}
	private:
		bool _activated;
		ListJobsCommand^ cmd;

		void RefreshView1()
		{
			listView1->BeginUpdate();
			try
			{
				if (cmd == nullptr)
					cmd = gcnew ListJobsCommand();
				_executer->Execute(cmd);
				listView1->Items->Clear();
				for each(Job^ job in cmd->Jobs)
				{
					ListViewItem^ lvi = listView1->Items->Add(job->DisplayName);
					lvi->Tag = job;
					String^ stateStr = job->State.ToString();
					if (!String::IsNullOrEmpty(job->ErrorDescription))
						stateStr += ": " + job->ErrorDescription;
					lvi->SubItems->Add(stateStr);
					lvi->SubItems->Add(String::Format("{0}", job->Files->Count));
					lvi->SubItems->Add(String::Format("{0:0.0}%", job->PercentCompleted));
					lvi->SubItems->Add(GetReadableSize(job->TotalBytes));
					lvi->ToolTipText = job->ErrorDescription;
				}		
			}
			finally
			{
				listView1->EndUpdate();
			}

		}

		void RefreshView2()
		{
			listView2->BeginUpdate();
			try
			{
				listView2->Items->Clear();
				Job^ job = (Job^)listView1->SelectedItems[0]->Tag;
				for each(File^ file in job->Files)
				{

					ListViewItem^ lvi = listView2->Items->Add(file->FileName);
					lvi->Tag = file;
					lvi->SubItems->Add(String::Format("{0:0.0}%", file->PercentCompleted));
					lvi->SubItems->Add(GetReadableSize(file->TotalBytes));
					//lvi->ToolTipText = job->ErrorDescription;
				}		
			}
			finally
			{
				listView2->EndUpdate();
			}
		}

		static String^ GetReadableSize(__int64 size)
		{
			if (size < 1024)
				return String::Format("{0} B", size);
			size /= 1024;
			if (size < 1024)
				return String::Format("{0} KB", size);
			size /= 1024;
			if (size < 1024)
				return String::Format("{0} MB", size);
			size /= 1024;
			if (size < 1024)
				return String::Format("{0} GB", size);
			size /= 1024;
			return String::Format("{0} TB", size);
		}

	private:
		System::Void cmdDelete_Click(System::Object^  sender, System::EventArgs^  e) {
			Job^ job = (Job^)listView1->SelectedItems[0]->Tag;
			if (job->State == JobState::Transferred)
				job->Complete();
			else
				job->Cancel();
			RefreshView1();
		}

		System::Void listBox1_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
			cmdDelete->Enabled = listView1->SelectedItems->Count == 1;
			cmdResume->Enabled = cmdDelete->Enabled && 
				((Job^)listView1->SelectedItems[0]->Tag)->CanResume;
			if (!cmdDelete->Enabled)
				listView2->Items->Clear();
			else
				RefreshView2();
		}
	private: System::Void cmdResume_Click(System::Object^  sender, System::EventArgs^  e) {
				 Job^ job = (Job^)listView1->SelectedItems[0]->Tag;
				 job->Resume();
			 }

	private: System::Void StatusForm_FormClosed(System::Object^  sender, System::Windows::Forms::FormClosedEventArgs^  e) {
				 if (cmd != nullptr)
					 delete cmd;
			 }
	private: System::Void listView1_ItemActivate(System::Object^  sender, System::EventArgs^  e) {
			 }
	};
}
