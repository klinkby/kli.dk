#pragma once
#include "ICommand.h"
namespace BITSync
{
	interface class ICommandExecuter {
		void Execute(ICommand^ cmd);
	};
}