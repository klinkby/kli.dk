#pragma once
#include "ICommand.h"
#include "FileRef.h"

namespace BITSync
{
	using namespace System;
	using namespace System::Windows::Forms;

	ref class DeleteCommand : ICommand {
	private:
		FileRef^ _fileRef;
	public:
		property FileRef^ File
		{
			FileRef^ get() {
				return _fileRef;
			}
			void set(FileRef^ value) {
				_fileRef = value;
			}
		}
		virtual void Execute(SetStatusCallback^ setStatus)
		{
			HKEY hOutKey;
			if (RegCreateKeyExW(HKEY_CURRENT_USER, registryPathsKey, 
				NULL, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS,
				NULL, &hOutKey, NULL) ==  ERROR_SUCCESS)
			{			
				IntPtr pLocal = Marshal::StringToHGlobalUni(_fileRef->LocalFile);
				try {
					RegDeleteValueW(hOutKey, (LPCWSTR)pLocal.ToPointer());
				}
				finally {
					Marshal::FreeHGlobal(pLocal);				
					RegCloseKey(hOutKey);			
				}
			}
		}
	};
}