#pragma once
#include "FileRef.h"
namespace BITSync {
	using namespace System;
	using namespace System::IO;
	using namespace System::Diagnostics;

ref class File : FileRef, IDisposable
{
private:
	IBackgroundCopyFile *m_pFile;
public:
	File(IBackgroundCopyFile* pFile) : m_pFile(pFile), 
		FileRef(File::GetLocalFile(pFile), File::GetRemoteFile(pFile))
	{
		Debug::Assert(pFile != NULL);			
	}

	property float PercentCompleted {
		float get() {
			BG_FILE_PROGRESS progress;
			m_pFile->GetProgress(&progress);
			if (progress.BytesTotal == 0)
				return 0;
			return (float)(progress.BytesTransferred * 100.0 / progress.BytesTotal);
		};
	}

	property UInt64 TotalBytes
	{
		UInt64 get() {
			BG_FILE_PROGRESS progress;
			m_pFile->GetProgress(&progress);
			return progress.BytesTotal;
		}
	}

	property String^ FileName {
		String^ get() {
			String^ filePath = GetLocalFile(m_pFile);
			return Path::GetFileName(filePath);
		};
	}

private:
	static String^ GetLocalFile(IBackgroundCopyFile* pFile) {
		LPWSTR sz;
		pFile->GetLocalName(&sz);
		String^ str = gcnew String(sz);
		CoTaskMemFree(sz);
		return str;
	}

	static String^ GetRemoteFile(IBackgroundCopyFile* pFile) {
		LPWSTR sz;
		pFile->GetRemoteName(&sz);
		String^ str = gcnew String(sz);
		CoTaskMemFree(sz);
		return str;
	}

private:
	~File()
	{
		this->!File();
	}
protected:
	!File()
	{
		if (m_pFile != NULL)
			m_pFile->Release();
		m_pFile = NULL;
	}
};
}