#pragma once

#include "FileRef.h"
#include "CRC32.h"

namespace BITSync {
	using namespace System;
	using namespace System::Collections::Generic;
	using namespace System::IO;
	using namespace System::Diagnostics;
	using namespace System::Runtime::InteropServices;

	ref class FileSet
	{
	private:
		Dictionary<int, String^>^ 
			_paths;
		String^ _baseDir;
		String^ _includePattern;
		String^ _excludePattern;

	public:
		FileSet(String^ path, String^ includePattern, String^ excludePattern)
			: _includePattern(includePattern), _excludePattern(excludePattern)
		{
			_paths = gcnew Dictionary<int, String^>();
			_baseDir = path;
			if (Directory::Exists(path) 
				&& !path->EndsWith(Path::DirectorySeparatorChar.ToString()))
				_baseDir += Path::DirectorySeparatorChar;
			Walk(_baseDir);
		}

		property String^ BaseDir
		{
			String^ get() {
				return _baseDir;
			}
		}

	private:
		String^ GetRebased(String^ path)
		{
			return path->Substring(_baseDir->Length);
		}

		void Walk(String^ path)
		{
			_paths->Clear();
			array<String^>^ dirs = Directory::GetDirectories(path, "*", SearchOption::AllDirectories);
			for each(String^ dir in dirs)
			{
				String^ storedFilePath = String::Concat("D", GetRebased(dir));
				_paths->Add(GetKey(storedFilePath), storedFilePath);
			}
			array<String^>^ includedFiles = Directory::GetFiles(path, _includePattern, SearchOption::AllDirectories);
			array<String^>^ excludedFiles = Directory::GetFiles(path, _excludePattern, SearchOption::AllDirectories);
			array<String^>::Sort(excludedFiles);
			for each(String^ includedFile in includedFiles)
			{
				if (!array<String^>::BinarySearch(excludedFiles, includedFile) == 0)
				{
					String^ storedFilePath = String::Concat("F", GetRebased(includedFile));
					_paths->Add(GetKey(storedFilePath), storedFilePath);
				}
			}
		}

		static Int32 GetKey(String^ value)
		{
			Crc32 crc32;
			IntPtr ptr = Marshal::StringToHGlobalAnsi(value);
			crc32.Compute(ptr.ToPointer(), value->Length);
			Marshal::FreeHGlobal(ptr);
			return crc32;
		}

		System::Collections::Generic::IList<String^>^ GetDiff(FileSet^ fileSet, Char ch)
		{
			List<String^>^ diff = gcnew List<String^>();
			for each(int key in fileSet->_paths->Keys)
			{
				String^ value;
				fileSet->_paths->TryGetValue(key, value);
				if (!_paths->ContainsKey(key) && value[0] == ch)
				{					
					diff->Add(value->Substring(1));
				}
			}
			return diff->AsReadOnly();
		}
	public:
		System::Collections::Generic::IList<String^>^ GetDiffDirs(FileSet^ fileSet)
		{
			return GetDiff(fileSet, 'D');
		}
		System::Collections::Generic::IList<String^>^ GetDiffFiles(FileSet^ fileSet)
		{
			return GetDiff(fileSet, 'F');
		}		
	};


}