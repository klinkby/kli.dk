#pragma once
#include "AllCommands.h"
#include "StatusForm.h"
#include "NewPathForm.h"
#include "HelpResource.h"
#include "OptionsForm.h"
#include "ICommandExecuter.h"

namespace BITSync {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections::Generic;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Threading;

	/// <summary>
	/// Summary for Form1
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource mpiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>

	
	ref class Form1 : public System::Windows::Forms::Form, ICommandExecuter
	{
	private:
		bool _activated;
		Options^ _settings;
	public:
		Form1(void): _activated(false)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::ToolStripContainer^  toolStripContainer1;
	protected: 

	private: System::Windows::Forms::ListView^  lbPaths;
	private: System::Windows::Forms::ColumnHeader^  clRemote;
	private: System::Windows::Forms::ColumnHeader^  clLocal;


	private: System::Windows::Forms::MenuStrip^  menuStrip2;
	private: System::Windows::Forms::ToolStripMenuItem^  fileToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  exitToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  pathsToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  addToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  deleteToolStripMenuItem;
	private: System::Windows::Forms::ToolStripSeparator^  toolStripMenuItem1;
	private: System::Windows::Forms::ToolStripMenuItem^  synchronizeToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  viewToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  bITSStatusToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  helpToolStripMenuItem;
	private: System::Windows::Forms::ToolStripSeparator^  toolStripMenuItem2;
	private: System::Windows::Forms::ToolStripMenuItem^  aboutToolStripMenuItem;
	private: System::Windows::Forms::StatusStrip^  statusStrip1;
	private: System::Windows::Forms::ToolStripStatusLabel^  toolStripStatusLabel1;
	private: System::Windows::Forms::ToolStripProgressBar^  toolStripProgressBar1;
	private: System::Windows::Forms::ToolStripMenuItem^  indexToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  synchronizeAllToolStripMenuItem;
	private: System::Windows::Forms::ToolStripSeparator^  toolStripMenuItem3;
	private: System::Windows::Forms::ToolStripMenuItem^  optionsToolStripMenuItem;
	private: System::ComponentModel::IContainer^  components;
	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->toolStripContainer1 = (gcnew System::Windows::Forms::ToolStripContainer());
			this->statusStrip1 = (gcnew System::Windows::Forms::StatusStrip());
			this->toolStripStatusLabel1 = (gcnew System::Windows::Forms::ToolStripStatusLabel());
			this->toolStripProgressBar1 = (gcnew System::Windows::Forms::ToolStripProgressBar());
			this->lbPaths = (gcnew System::Windows::Forms::ListView());
			this->clRemote = (gcnew System::Windows::Forms::ColumnHeader());
			this->clLocal = (gcnew System::Windows::Forms::ColumnHeader());
			this->menuStrip2 = (gcnew System::Windows::Forms::MenuStrip());
			this->fileToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->exitToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->pathsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->addToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->deleteToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->synchronizeToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->synchronizeAllToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->viewToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->bITSStatusToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripMenuItem3 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->optionsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->helpToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->indexToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripMenuItem2 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->aboutToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripContainer1->BottomToolStripPanel->SuspendLayout();
			this->toolStripContainer1->ContentPanel->SuspendLayout();
			this->toolStripContainer1->TopToolStripPanel->SuspendLayout();
			this->toolStripContainer1->SuspendLayout();
			this->statusStrip1->SuspendLayout();
			this->menuStrip2->SuspendLayout();
			this->SuspendLayout();
			// 
			// toolStripContainer1
			// 
			// 
			// toolStripContainer1.BottomToolStripPanel
			// 
			this->toolStripContainer1->BottomToolStripPanel->Controls->Add(this->statusStrip1);
			// 
			// toolStripContainer1.ContentPanel
			// 
			this->toolStripContainer1->ContentPanel->Controls->Add(this->lbPaths);
			this->toolStripContainer1->ContentPanel->Size = System::Drawing::Size(490, 111);
			this->toolStripContainer1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->toolStripContainer1->Location = System::Drawing::Point(0, 0);
			this->toolStripContainer1->Name = L"toolStripContainer1";
			this->toolStripContainer1->Size = System::Drawing::Size(490, 157);
			this->toolStripContainer1->TabIndex = 0;
			this->toolStripContainer1->Text = L"toolStripContainer1";
			// 
			// toolStripContainer1.TopToolStripPanel
			// 
			this->toolStripContainer1->TopToolStripPanel->Controls->Add(this->menuStrip2);
			// 
			// statusStrip1
			// 
			this->statusStrip1->Dock = System::Windows::Forms::DockStyle::None;
			this->statusStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->toolStripStatusLabel1, 
				this->toolStripProgressBar1});
			this->statusStrip1->Location = System::Drawing::Point(0, 0);
			this->statusStrip1->Name = L"statusStrip1";
			this->statusStrip1->Size = System::Drawing::Size(490, 22);
			this->statusStrip1->TabIndex = 0;
			// 
			// toolStripStatusLabel1
			// 
			this->toolStripStatusLabel1->Name = L"toolStripStatusLabel1";
			this->toolStripStatusLabel1->Size = System::Drawing::Size(475, 17);
			this->toolStripStatusLabel1->Spring = true;
			this->toolStripStatusLabel1->Text = L"Loading...";
			this->toolStripStatusLabel1->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			// 
			// toolStripProgressBar1
			// 
			this->toolStripProgressBar1->Name = L"toolStripProgressBar1";
			this->toolStripProgressBar1->Size = System::Drawing::Size(100, 16);
			this->toolStripProgressBar1->Visible = false;
			// 
			// lbPaths
			// 
			this->lbPaths->Columns->AddRange(gcnew cli::array< System::Windows::Forms::ColumnHeader^  >(2) {this->clRemote, this->clLocal});
			this->lbPaths->Dock = System::Windows::Forms::DockStyle::Fill;
			this->lbPaths->HeaderStyle = System::Windows::Forms::ColumnHeaderStyle::Nonclickable;
			this->lbPaths->Location = System::Drawing::Point(0, 0);
			this->lbPaths->MultiSelect = false;
			this->lbPaths->Name = L"lbPaths";
			this->lbPaths->Size = System::Drawing::Size(490, 111);
			this->lbPaths->TabIndex = 10;
			this->lbPaths->UseCompatibleStateImageBehavior = false;
			this->lbPaths->View = System::Windows::Forms::View::Details;
			this->lbPaths->SelectedIndexChanged += gcnew System::EventHandler(this, &Form1::lbPaths_SelectedIndexChanged);
			// 
			// clRemote
			// 
			this->clRemote->Text = L"Remote";
			this->clRemote->Width = 226;
			// 
			// clLocal
			// 
			this->clLocal->Text = L"Local";
			this->clLocal->Width = 178;
			// 
			// menuStrip2
			// 
			this->menuStrip2->Dock = System::Windows::Forms::DockStyle::None;
			this->menuStrip2->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(4) {this->fileToolStripMenuItem, 
				this->pathsToolStripMenuItem, this->viewToolStripMenuItem, this->helpToolStripMenuItem});
			this->menuStrip2->Location = System::Drawing::Point(0, 0);
			this->menuStrip2->Name = L"menuStrip2";
			this->menuStrip2->Size = System::Drawing::Size(490, 24);
			this->menuStrip2->TabIndex = 0;
			this->menuStrip2->Text = L"menuStrip2";
			// 
			// fileToolStripMenuItem
			// 
			this->fileToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->exitToolStripMenuItem});
			this->fileToolStripMenuItem->Name = L"fileToolStripMenuItem";
			this->fileToolStripMenuItem->Size = System::Drawing::Size(37, 20);
			this->fileToolStripMenuItem->Text = L"&File";
			// 
			// exitToolStripMenuItem
			// 
			this->exitToolStripMenuItem->Name = L"exitToolStripMenuItem";
			this->exitToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Alt | System::Windows::Forms::Keys::F4));
			this->exitToolStripMenuItem->Size = System::Drawing::Size(134, 22);
			this->exitToolStripMenuItem->Text = L"&Exit";
			this->exitToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::exitToolStripMenuItem_Click);
			// 
			// pathsToolStripMenuItem
			// 
			this->pathsToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(5) {this->addToolStripMenuItem, 
				this->deleteToolStripMenuItem, this->toolStripMenuItem1, this->synchronizeToolStripMenuItem, this->synchronizeAllToolStripMenuItem});
			this->pathsToolStripMenuItem->Name = L"pathsToolStripMenuItem";
			this->pathsToolStripMenuItem->Size = System::Drawing::Size(43, 20);
			this->pathsToolStripMenuItem->Text = L"&Path";
			// 
			// addToolStripMenuItem
			// 
			this->addToolStripMenuItem->Name = L"addToolStripMenuItem";
			this->addToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Control | System::Windows::Forms::Keys::N));
			this->addToolStripMenuItem->Size = System::Drawing::Size(210, 22);
			this->addToolStripMenuItem->Text = L"&New...";
			this->addToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::addToolStripMenuItem_Click);
			// 
			// deleteToolStripMenuItem
			// 
			this->deleteToolStripMenuItem->Enabled = false;
			this->deleteToolStripMenuItem->Name = L"deleteToolStripMenuItem";
			this->deleteToolStripMenuItem->ShortcutKeys = System::Windows::Forms::Keys::Delete;
			this->deleteToolStripMenuItem->Size = System::Drawing::Size(210, 22);
			this->deleteToolStripMenuItem->Text = L"&Delete";
			this->deleteToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::deleteToolStripMenuItem_Click);
			// 
			// toolStripMenuItem1
			// 
			this->toolStripMenuItem1->Name = L"toolStripMenuItem1";
			this->toolStripMenuItem1->Size = System::Drawing::Size(207, 6);
			// 
			// synchronizeToolStripMenuItem
			// 
			this->synchronizeToolStripMenuItem->Enabled = false;
			this->synchronizeToolStripMenuItem->Name = L"synchronizeToolStripMenuItem";
			this->synchronizeToolStripMenuItem->ShortcutKeys = System::Windows::Forms::Keys::F5;
			this->synchronizeToolStripMenuItem->Size = System::Drawing::Size(210, 22);
			this->synchronizeToolStripMenuItem->Text = L"&Synchronize...";
			this->synchronizeToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::synchronizeToolStripMenuItem_Click);
			// 
			// synchronizeAllToolStripMenuItem
			// 
			this->synchronizeAllToolStripMenuItem->Name = L"synchronizeAllToolStripMenuItem";
			this->synchronizeAllToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Control | System::Windows::Forms::Keys::F5));
			this->synchronizeAllToolStripMenuItem->Size = System::Drawing::Size(210, 22);
			this->synchronizeAllToolStripMenuItem->Text = L"Synchronize All...";
			this->synchronizeAllToolStripMenuItem->Visible = false;
			this->synchronizeAllToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::synchronizeAllToolStripMenuItem_Click);
			// 
			// viewToolStripMenuItem
			// 
			this->viewToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->bITSStatusToolStripMenuItem, 
				this->toolStripMenuItem3, this->optionsToolStripMenuItem});
			this->viewToolStripMenuItem->Name = L"viewToolStripMenuItem";
			this->viewToolStripMenuItem->Size = System::Drawing::Size(48, 20);
			this->viewToolStripMenuItem->Text = L"&Tools";
			// 
			// bITSStatusToolStripMenuItem
			// 
			this->bITSStatusToolStripMenuItem->Name = L"bITSStatusToolStripMenuItem";
			this->bITSStatusToolStripMenuItem->ShortcutKeys = System::Windows::Forms::Keys::F4;
			this->bITSStatusToolStripMenuItem->Size = System::Drawing::Size(160, 22);
			this->bITSStatusToolStripMenuItem->Text = L"BITS &Status...";
			this->bITSStatusToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::bITSStatusToolStripMenuItem_Click);
			// 
			// toolStripMenuItem3
			// 
			this->toolStripMenuItem3->Name = L"toolStripMenuItem3";
			this->toolStripMenuItem3->Size = System::Drawing::Size(157, 6);
			// 
			// optionsToolStripMenuItem
			// 
			this->optionsToolStripMenuItem->Name = L"optionsToolStripMenuItem";
			this->optionsToolStripMenuItem->Size = System::Drawing::Size(160, 22);
			this->optionsToolStripMenuItem->Text = L"&Options...";
			this->optionsToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::optionsToolStripMenuItem_Click);
			// 
			// helpToolStripMenuItem
			// 
			this->helpToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->indexToolStripMenuItem, 
				this->toolStripMenuItem2, this->aboutToolStripMenuItem});
			this->helpToolStripMenuItem->Name = L"helpToolStripMenuItem";
			this->helpToolStripMenuItem->Size = System::Drawing::Size(44, 20);
			this->helpToolStripMenuItem->Text = L"&Help";
			// 
			// indexToolStripMenuItem
			// 
			this->indexToolStripMenuItem->Name = L"indexToolStripMenuItem";
			this->indexToolStripMenuItem->ShortcutKeys = System::Windows::Forms::Keys::F1;
			this->indexToolStripMenuItem->Size = System::Drawing::Size(152, 22);
			this->indexToolStripMenuItem->Text = L"&Index";
			this->indexToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::indexToolStripMenuItem_Click);
			// 
			// toolStripMenuItem2
			// 
			this->toolStripMenuItem2->Name = L"toolStripMenuItem2";
			this->toolStripMenuItem2->Size = System::Drawing::Size(149, 6);
			// 
			// aboutToolStripMenuItem
			// 
			this->aboutToolStripMenuItem->Name = L"aboutToolStripMenuItem";
			this->aboutToolStripMenuItem->Size = System::Drawing::Size(152, 22);
			this->aboutToolStripMenuItem->Text = L"&About BITSync";
			this->aboutToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::aboutToolStripMenuItem_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(490, 157);
			this->Controls->Add(this->toolStripContainer1);
			this->MinimumSize = System::Drawing::Size(373, 166);
			this->Name = L"Form1";
			this->Text = L"Klinkby BITSync";
			this->Activated += gcnew System::EventHandler(this, &Form1::Form1_Activated);
			this->toolStripContainer1->BottomToolStripPanel->ResumeLayout(false);
			this->toolStripContainer1->BottomToolStripPanel->PerformLayout();
			this->toolStripContainer1->ContentPanel->ResumeLayout(false);
			this->toolStripContainer1->TopToolStripPanel->ResumeLayout(false);
			this->toolStripContainer1->TopToolStripPanel->PerformLayout();
			this->toolStripContainer1->ResumeLayout(false);
			this->toolStripContainer1->PerformLayout();
			this->statusStrip1->ResumeLayout(false);
			this->statusStrip1->PerformLayout();
			this->menuStrip2->ResumeLayout(false);
			this->menuStrip2->PerformLayout();
			this->ResumeLayout(false);

		}
#pragma endregion
	private:
		delegate void RefreshViewCallback();

		void RefreshView()
		{
			if (InvokeRequired)
			Invoke(
			gcnew RefreshViewCallback(this, &Form1::_RefreshView), 
				gcnew array<Object^> (0)
		);
		else
			_RefreshView();
		}
		void _RefreshView()
		{
			ListPathsCommand^ cmd = gcnew ListPathsCommand();
			Execute(cmd);
			lbPaths->Items->Clear();
			for each (FileRef^ path in cmd->Paths)
			{
				ListViewItem^ item = lbPaths->Items->Add(path->RemoteFile);
				item->SubItems->Add(path->LocalFile);
				item->Tag = path;
			}
			delete cmd;
		}
	private: 
		System::Void Form1_Activated(System::Object^  sender, System::EventArgs^  e) {
			if (!_activated)
			{
				_activated = true;
				RefreshView();
			}
		 }

		 System::Void cmdAddJob_Click(System::Object^  sender, System::EventArgs^  e) {
			/*bitService->CreateJob(
				"dm", gcnew array<FileRef^> {
					gcnew FileRef("c:\\temp\\45m.jpg", "http://ia.imdb.com/media/imdb/01/I/02/30/45m.jpg")
			});
			RefreshView();*/

			 //FileSet^ local = gcnew FileSet("c:\\temp");//.Synchronize();
			 //FileSet^ remote = gcnew FileSet("m:\\");
			 //array<String^>^ dirs = local->GetDiffDirs(remote);
			 //array<String^>^ files = local->GetDiffFiles(remote);
			 //CreateDirs(local->BaseDir, dirs);
			 //CreateDownloadJob(gcnew FileRef(local->BaseDir, remote->BaseDir), files);

			 
			 //SynchronizeForm synchronizeForm(bitService, 
			//	gcnew FileRef("c:\\temp", "m:\\"));
			//synchronizeForm.ShowDialog(this);
		 }
public:
	virtual void Execute(ICommand^ cmd)
	{
		SetStatus("Please wait", 0);
		try
		{
			cmd->Execute(gcnew SetStatusCallback(
				this,
				&Form1::SetStatus)
				);
		}
		catch(Exception ^e)
		{
			ShowError(e->ToString());
		}
		SetStatus("Ready", 100);
		if (cmd->GetType() != ListPathsCommand::typeid)
			RefreshView();
	}

	void ExecuteAsync(ICommand^ cmd)
	{
		ThreadPool::QueueUserWorkItem(
			gcnew WaitCallback(this,
			&Form1::_ExecuteAsync), cmd);	
	}

	void _ExecuteAsync(Object^ obj)
	{
		ICommand^ cmd = (ICommand^)obj;
		Execute(cmd);
		delete cmd;		
	}



	//void SetState(bool busy)
	//{
	//	if (InvokeRequired)
	//		Invoke(
	//		gcnew SetStateCallback(this, &Form1::_SetState), 
	//			gcnew array<Object^> {busy}
	//	);
	//	else
	//		_SetState(busy);
	//}


	void SetState(bool busy)
	{
		Cursor = busy ? Cursors::AppStarting : Cursors::Default;
		toolStripProgressBar1->Visible = busy;
	}

	delegate void ShowErrorCallback(String^ text);
	void ShowError(String^ text)
	{
		if (InvokeRequired)
			Invoke(
			gcnew ShowErrorCallback(this, &Form1::_ShowError), 
				gcnew array<Object^> {text}
		);
		else
			_ShowError(text);
	}


	void _ShowError(String^ text)
	{
		MessageBox::Show(
			this,
			text,
			L"BITSync Error",
			System::Windows::Forms::MessageBoxButtons::OK,
			System::Windows::Forms::MessageBoxIcon::Exclamation);
	}

	void SetStatus(String^ text, Byte percentComplete)
	{
		if (InvokeRequired)
			Invoke(
			gcnew SetStatusCallback(this, &Form1::_SetStatus), 
				gcnew array<Object^> {text, percentComplete}
		);
		else
			_SetStatus(text, percentComplete);
	}

	 void _SetStatus(String^ text, Byte percentComplete)
	 {
		toolStripStatusLabel1->Text = text;
		toolStripProgressBar1->Value = percentComplete;
		if (percentComplete == 0)
			SetState(true);
		if (percentComplete == 100)
			SetState(false);
		Refresh();		
	 }


private: 
	System::Void synchronizeToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
		SynchronizeOneCommand^ cmd = gcnew SynchronizeOneCommand();
		cmd->File = (FileRef^)lbPaths->SelectedItems[0]->Tag;
		cmd->Settings = Settings;
		ExecuteAsync(cmd);
		 }
private: System::Void bITSStatusToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			StatusForm frm(this);
			frm.ShowDialog(this);
		 }
private: System::Void synchronizeAllToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void exitToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 Application::Exit();
		 }
private: System::Void addToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 NewPathForm frm;
			 if (frm.ShowDialog(this) == System::Windows::Forms::DialogResult::OK)
			 {
				 if (frm.LocalPath != nullptr && frm.RemotePath != nullptr)
				 {
					 AddCommand^ cmd = gcnew AddCommand();				 
					 cmd->File = gcnew FileRef(frm.LocalPath, frm.RemotePath);
					 Execute(cmd);
					 delete cmd;
				 }
			 }
		 }
private: System::Void deleteToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 DeleteCommand^ cmd = gcnew DeleteCommand();
			 cmd->File = (FileRef^)lbPaths->SelectedItems[0]->Tag;
			 Execute(cmd);
			 delete cmd;
		 }
private: System::Void indexToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 String^ tempPath = Environment::ExpandEnvironmentVariables("%temp%\\BITSyncHelp.htm");			 
			 if (!System::IO::File::Exists(tempPath))
			 {
				 System::Resources::ResourceManager rm(HelpResource::typeid);
				 FileInfo fi(tempPath);
				 StreamWriter^ s = fi.CreateText();			 
				 String^ helpString = (String^)rm.GetObject("Help.htm");
				 s->Write(helpString);
				 s->Close();
				 delete s;
			 }
			 ProcessStartInfo^ psi = gcnew ProcessStartInfo();
			 psi->FileName = "iexplore.exe";
			 psi->Arguments = tempPath;
			 psi->UseShellExecute = true;
			 Process::Start(psi);			 
			 delete psi;
		 }
private: System::Void aboutToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 MessageBox::Show(
				 this,
				 L"Monitors folders on remote shares and copies files to local file system using the Background Intelligent Transfer Service (BITS), which uses idle bandwith, supports resuming and much more to support reliable tranfers on unreliable networks.\r\n\r\n(c) 2008 Mads Klinkby [http://kli.dk/]",
				 L"About Klinkby BITSync v1.0",
				 System::Windows::Forms::MessageBoxButtons::OK,
				 System::Windows::Forms::MessageBoxIcon::Information);
		 }
private: System::Void optionsToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			OptionsForm frm;
			frm.Settings = (Options^)Settings->Clone();
			if (frm.ShowDialog(this) == System::Windows::Forms::DialogResult::OK)
			{
				Settings = frm.Settings;
			}
		 }
		 property Options^ Settings
		 {
			Options^ get() {
				if (_settings == nullptr)
				{
					LoadOptionsCommand^ cmd = gcnew LoadOptionsCommand();
					Execute(cmd);
					_settings = cmd->Settings;
					delete cmd;
				}
				return _settings;
			}
			void set(Options^ value)
			{
				SaveOptionsCommand^ cmd = gcnew SaveOptionsCommand();
				cmd->Settings = _settings =  value;
				Execute(cmd);
				delete cmd;
			}
		 }
private: System::Void lbPaths_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
			 bool oneSelected = lbPaths->SelectedItems->Count == 1;
			 deleteToolStripMenuItem->Enabled = oneSelected;
			 synchronizeToolStripMenuItem->Enabled = oneSelected;
		 }
};



}

