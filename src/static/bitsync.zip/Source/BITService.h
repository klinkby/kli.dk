#pragma once
#include "Job.h"
namespace BITSync {
	using namespace System;
	using namespace System::Collections::Generic;
	using namespace System::Diagnostics;
	using namespace System::Runtime::InteropServices;

	ref class BITService
	{
	private:
		IBackgroundCopyManager* m_pbcm;
		array<Job^>^ jobs;
	public:
		BITService() : m_pbcm(NULL)
		{
			IBackgroundCopyManager *pBcm = NULL;
			HRESULT hr = CoCreateInstance(__uuidof(BackgroundCopyManager), NULL,
				CLSCTX_LOCAL_SERVER,
				__uuidof(IBackgroundCopyManager),
				(void**) &pBcm);
			if (SUCCEEDED(hr)) {
				m_pbcm = pBcm;
			}
		}
		BITService(IBackgroundCopyManager* pbcm) : m_pbcm(pbcm), jobs(nullptr)
		{
			Debug::Assert(pbcm != NULL);			
		}

		property IList<Job^>^ Jobs
		{
			IList<Job^>^ get() {
				if (jobs == nullptr)
				{
					IEnumBackgroundCopyJobs* pJobs = NULL;	
					HRESULT hr = m_pbcm->EnumJobsW(0, &pJobs);
					if (SUCCEEDED(hr))
					{
						ULONG count;
						hr = pJobs->GetCount(&count);
						if (SUCCEEDED(hr))
						{
							jobs = gcnew array<Job^>(count);
							for(UINT i=0; i<count; i++)
							{
								IBackgroundCopyJob* pJob = NULL;
								hr = pJobs->Next(1, &pJob, NULL);
								if (SUCCEEDED(hr))
								{			
									jobs->SetValue(gcnew Job(pJob), (int)i);
								}
							}
						}
						pJobs->Release();
					}
				}
				return array<Job^>::AsReadOnly(jobs);
			}
		}

		void CreateJob(String^ displayName, array<FileRef^>^ files)
		{
			Debug::Assert(displayName != nullptr);			
			Debug::Assert(files != nullptr);
			IntPtr pDisplay = Marshal::StringToCoTaskMemUni(displayName);
			LPCWSTR szDisplayName = (LPCWSTR)pDisplay.ToPointer();
			GUID guid;
			//CoCreateGuid(&guid);
			IBackgroundCopyJob *pJob;
			HRESULT hr = m_pbcm->CreateJob(szDisplayName, BG_JOB_TYPE_DOWNLOAD, &guid, &pJob);
			Marshal::FreeCoTaskMem(pDisplay);
			if (SUCCEEDED(hr))
			{
				BG_FILE_INFO* fileSet = new BG_FILE_INFO[files->Length];
				for(int i=0; i<files->Length; i++)
				{
					FileRef^ file = (FileRef^)files->GetValue(i);
					IntPtr pRemoteFile = Marshal::StringToBSTR(file->RemoteFile);
					IntPtr pLocalFile = Marshal::StringToBSTR(file->LocalFile);
					BG_FILE_INFO* pFI = &fileSet[i];
					pFI->LocalName = (LPWSTR)pLocalFile.ToPointer();
					pFI->RemoteName = (LPWSTR)pRemoteFile.ToPointer();
					//Debug::Assert(SUCCEEDED(hr));
					//Marshal::FreeBSTR(pRemoteFile);
					//Marshal::FreeBSTR(pLocalFile);
				}
				hr = pJob->AddFileSet(files->Length, fileSet);
				for(int i=0; i<files->Length; i++)
				{
					BG_FILE_INFO* pFI = &fileSet[i];
					Marshal::FreeBSTR(IntPtr(pFI->LocalName));
					Marshal::FreeBSTR(IntPtr(pFI->RemoteName));
				}
				delete fileSet;
				if (FAILED(hr))
					switch (hr)
				{
					case BG_E_TOO_MANY_FILES:
						throw gcnew Exception("Upload jobs can only contain one file; you cannot add another file to the job.");
						break;
					case BG_E_TOO_MANY_FILES_IN_JOB:
						throw gcnew Exception("Too many files in job. The MaxFilesPerJob Group Policy setting determines how many files a job can contain. Adding the file to the job exceeds the MaxFilesPerJob limit.");
						break;
					case E_ACCESSDENIED:
						throw gcnew Exception("Access Denied. User does not have permission to write to the specified directory on the client.");
						break;
					case E_INVALIDARG:
					default:
						throw gcnew Exception("Invalid argument. The local or remote file name is not valid or the remote file name uses an unsupported protocol.");
						break;
						pJob->Resume();
						pJob->Release();
				}
				ClearCachedJobs();
			}
		}

		private:
			~BITService()
			{
				this->!BITService();
			}

		protected:
			!BITService()
			{
				ClearCachedJobs();
				if (m_pbcm != NULL)
					m_pbcm->Release();
				m_pbcm = NULL;
			}
		private:
			void ClearCachedJobs()
			{
				if (jobs != nullptr)
					for(int i=0; i<jobs->Length; i++)
						delete jobs->GetValue(i);		
				jobs = nullptr;
			}
		};
	}