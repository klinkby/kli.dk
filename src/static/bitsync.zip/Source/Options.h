#pragma once 

namespace BITSync
{
	using namespace System;
	using namespace System::ComponentModel;

	const LPCWSTR registryOptionsKey = L"Software\\BITSync\\Options";
	const LPCWSTR defIncludePattern = L"*.*";
	const LPCWSTR defExcludePattern = L"*.!ut;*.dat;*.db";

	ref class Options : ICloneable
	{
	private:
		String^ _includePattern;
		String^ _excludePattern;
	public:
		Options() : _includePattern(gcnew String(defIncludePattern)), _excludePattern(gcnew String(defExcludePattern))
		{
		}

		Options(
				String^ includePattern,
				String^ excludePattern)
		{
			_includePattern = includePattern;
			_excludePattern = excludePattern;
		}

		[BrowsableAttribute(true)]
		[CategoryAttribute(L"Paths")]
		[DefaultValueAttribute(L"*.*")]
		[DescriptionAttribute(L"Pattern for files to be included in the synchronization")]
		property String^ IncludePattern {
			String^ get(){
				return _includePattern;
			}
			void set(String^ value) {
				_includePattern = value;
			}
		}

		[BrowsableAttribute(true)]
		[CategoryAttribute(L"Paths")]
		[DescriptionAttribute(L"Pattern for files to be excluded in the synchronization")]
		[DefaultValueAttribute(L"*.!ut;*.dat;*.db")]
		property String^ ExcludePattern {
			String^ get(){
				return _excludePattern;
			}
			void set(String^ value) {
				_excludePattern = value;
			}
		}
		virtual Object^ Clone()
		{
			return gcnew Options(
				_includePattern,
				_excludePattern);
		}
	};
}