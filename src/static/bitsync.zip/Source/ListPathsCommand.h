#pragma once
#include "ICommand.h"
#include "FileRef.h"

namespace BITSync
{
	using namespace System;
	using namespace System::Collections::Generic;

	ref class ListPathsCommand : ICommand {
	private:
		array<FileRef^>^ _fileRefs;
	public:
		property System::Collections::Generic::IList<FileRef^>^ Paths
		{
			System::Collections::Generic::IList<FileRef^>^ get() {
				return array<FileRef^>::AsReadOnly(_fileRefs);
			}
		}
		virtual void Execute(SetStatusCallback^ setStatus)
		{
			System::Collections::Generic::List<FileRef^>^ fileRefs = gcnew
				System::Collections::Generic::List<FileRef^>();
			const int keysize = 1024;
			HKEY hOutKey;
			if (RegCreateKeyExW(HKEY_CURRENT_USER, registryPathsKey, 
				NULL, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS,
				NULL, &hOutKey, NULL) ==  ERROR_SUCCESS)
			{				
				LPWSTR lpName = new WCHAR[keysize];
				LPWSTR lpValue = new WCHAR[keysize];
				try {
					DWORD lpcName = keysize;
					DWORD lpcValue = keysize;
					for(int i=0; 
						RegEnumValueW(hOutKey, i, lpName, &lpcName, NULL, NULL, (LPBYTE)lpValue, &lpcValue) == ERROR_SUCCESS; 
						i++)
					{
						fileRefs->Add(gcnew FileRef(
							gcnew String(lpName),
							gcnew String(lpValue)
							));
						lpcName = keysize;
						lpcValue = keysize;					
					}
				}
				finally {
					delete lpValue;
					delete lpName;
					RegCloseKey(hOutKey);			
				}
			}
			_fileRefs = fileRefs->ToArray();
		}
	};
}