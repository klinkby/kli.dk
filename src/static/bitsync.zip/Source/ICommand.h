#pragma once
namespace BITSync
{
	public delegate void SetStatusCallback(System::String^ string, System::Byte percentComplete);

	interface class ICommand {
		void Execute(SetStatusCallback^ setStatus);
	};
}