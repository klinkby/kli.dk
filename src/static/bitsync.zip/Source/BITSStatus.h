#pragma once
#include "ICommand.h"

namespace BITSync
{
	using namespace System;
	using namespace System::Windows::Forms;

	ref class BITSStatusCommand : ICommand {
	public:
		virtual void Execute() override
		{
			
		}
	};
}