#pragma once
#include "ICommand.h"
#include "BITService.h"

namespace BITSync
{
	using namespace System;
	using namespace System::Collections::Generic;

	ref class ListJobsCommand : IDisposable, ICommand {
	private:
		BITService^ bitService;
		System::Collections::Generic::IList<Job^>^ jobs;
	public:
		property System::Collections::Generic::IList<Job^>^ Jobs
		{
			System::Collections::Generic::IList<Job^>^ get() {
				return jobs;
			}
		}
		virtual void Execute(SetStatusCallback^ setStatus)
		{
			bitService = gcnew BITService();
			jobs = bitService->Jobs;
		}
	private:
		~ListJobsCommand()
		{
			this->!ListJobsCommand();
		}

	protected:
		!ListJobsCommand()
		{
			delete bitService;
		}
	};
}