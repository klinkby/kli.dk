#pragma once

namespace BITSync {
	using namespace System;

	const LPCWSTR registryPathsKey = L"Software\\BITSync\\Paths";

	ref class FileRef
	{
	private:
		String^ _localFile;
		String^ _remoteFile;

	public:
		FileRef(String^ localFile, String^ remoteFile) 
			: _localFile(localFile), _remoteFile(remoteFile)
		{			
		}

		property String^ LocalFile {	
			String^ get() {
				return _localFile;
			}
		}
		property String^ RemoteFile {	
			String^ get() {
				return _remoteFile;
			}
		}
	};
}