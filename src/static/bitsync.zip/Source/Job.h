#pragma once
#include "File.h"
namespace BITSync 
{
	using namespace System;
	using namespace System::Diagnostics;
	using namespace System::Collections::Generic;

	enum class JobState
	{
		Queued			= BG_JOB_STATE_QUEUED		,
		Connecting		= BG_JOB_STATE_CONNECTING	,
		Transferring	= BG_JOB_STATE_TRANSFERRING	,
		Suspended		= BG_JOB_STATE_SUSPENDED	,
		Error			= BG_JOB_STATE_ERROR		,
		TransientError	= BG_JOB_STATE_TRANSIENT_ERROR,
		Transferred		= BG_JOB_STATE_TRANSFERRED	,
		Acknowledged	= BG_JOB_STATE_ACKNOWLEDGED	,
		Cancelled		= BG_JOB_STATE_CANCELLED	
	};

	ref class Job : IDisposable
	{
	private:
		IBackgroundCopyJob* m_pJob;
		array<File^>^ files;
	public:
		Job(IBackgroundCopyJob* pJob) : m_pJob(pJob), files(nullptr)
		{
			Debug::Assert(pJob != NULL);			
			if (State == JobState::Transferred)
				Complete();
			if (Files->Count == 0)
				Cancel();
		}

		property JobState State
		{
			JobState get() {
				BG_JOB_STATE state;
				m_pJob->GetState(&state);
				return (JobState)state;
			}
		}

		property float PercentCompleted
		{
			float get() {
				BG_JOB_PROGRESS progress;
				m_pJob->GetProgress(&progress);
				if (progress.BytesTotal == 0)
					return 0;
				return (float)(progress.BytesTransferred * 100.0 / progress.BytesTotal);
			};
		}

		property UInt64 TotalBytes
		{
			UInt64 get() {
				BG_JOB_PROGRESS progress;
				m_pJob->GetProgress(&progress);
				return progress.BytesTotal;
			}
		}

		property String^ DisplayName
		{
			String^ get() {
				LPWSTR sz;
				m_pJob->GetDisplayName(&sz);
				String^ str = gcnew String(sz);
				CoTaskMemFree(sz);
				return str;
			}
		}

		property String^ ErrorDescription
		{
			String^ get() {
				String^ str = nullptr;
				IBackgroundCopyError *pErr;
				HRESULT hr = m_pJob->GetError(&pErr);
				if (SUCCEEDED(hr))
				{
					LPWSTR sz;
					pErr->GetErrorDescription(1033, &sz);
					pErr->Release();
					str = gcnew String(sz);
					CoTaskMemFree(sz);
				}
				return str;
			}
		}

		property IList<File^>^ Files
		{
			IList<File^>^ get() {
				if (files == nullptr)
				{
					IEnumBackgroundCopyFiles *pFiles;
					HRESULT hr = m_pJob->EnumFiles(&pFiles);
					if (SUCCEEDED(hr))
					{
						ULONG count;
						pFiles->GetCount(&count);
						files = gcnew array<File^>(count);
						for(UINT i=0; i<count; i++)
						{
							IBackgroundCopyFile *pFile;
							hr = pFiles->Next(1, &pFile, NULL);
							if (SUCCEEDED(hr))
							{
								files->SetValue(
									gcnew File(pFile),
									(int)i);
							}
						}
					}
				}
				return array<File^>::AsReadOnly(files);
				//return files->AsReadOnly();
			}
		}

		property bool CanResume
		{
			bool get() {
				JobState state = State;
				return state == JobState::Error
					|| state == JobState::Suspended
					|| state == JobState::TransientError
					|| state == JobState::Queued;
			}
		}

		void Complete()
		{
			m_pJob->Complete();
		}

		void Cancel()
		{
			m_pJob->Cancel();
		}


		void Resume()
		{
			m_pJob->Resume();
		}		

		void Suspend()
		{
			m_pJob->Suspend();
		}		

		virtual String^ ToString() override
		{
			return String::Format(
				"{0:0.0} ({1}% of {2} kB)", 
				DisplayName,
				PercentCompleted,
				((__int64)TotalBytes) == -1 
				? (Object^)"?" 
				: (Object^)(TotalBytes >> 10));
		}

	private:
		~Job()
		{
			this->!Job();
		}
	protected:
		!Job()
		{
			if (files != nullptr)
				for(int i=0; i<files->Length; i++)
					delete files->GetValue(i);			
			files = nullptr;
			if (m_pJob != NULL)
				m_pJob->Release();
			m_pJob = NULL;
		}
	};

}