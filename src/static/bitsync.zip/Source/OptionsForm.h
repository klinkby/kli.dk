#pragma once

#include "Options.h"

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


namespace BITSync {

	/// <summary>
	/// Summary for OptionsForm
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class OptionsForm : public System::Windows::Forms::Form
	{
	public:
		OptionsForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

		Options^ _settings;
		property Options^ Settings
		{
			Options^ get() {
				return _settings;
			}
			void set(Options^ value) {
				propertyGrid1->SelectedObject = _settings = value;
			}
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~OptionsForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::PropertyGrid^  propertyGrid1;
	private: System::Windows::Forms::Button^  cmdOK;
	private: System::Windows::Forms::Button^  cmdCancel;


	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->propertyGrid1 = (gcnew System::Windows::Forms::PropertyGrid());
			this->cmdOK = (gcnew System::Windows::Forms::Button());
			this->cmdCancel = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// propertyGrid1
			// 
			this->propertyGrid1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom) 
				| System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->propertyGrid1->Location = System::Drawing::Point(0, 0);
			this->propertyGrid1->Name = L"propertyGrid1";
			this->propertyGrid1->Size = System::Drawing::Size(280, 215);
			this->propertyGrid1->TabIndex = 0;
			// 
			// cmdOK
			// 
			this->cmdOK->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Right));
			this->cmdOK->DialogResult = System::Windows::Forms::DialogResult::OK;
			this->cmdOK->Location = System::Drawing::Point(112, 221);
			this->cmdOK->Name = L"cmdOK";
			this->cmdOK->Size = System::Drawing::Size(75, 23);
			this->cmdOK->TabIndex = 1;
			this->cmdOK->Text = L"&OK";
			this->cmdOK->UseVisualStyleBackColor = true;
			// 
			// cmdCancel
			// 
			this->cmdCancel->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Right));
			this->cmdCancel->CausesValidation = false;
			this->cmdCancel->DialogResult = System::Windows::Forms::DialogResult::Cancel;
			this->cmdCancel->Location = System::Drawing::Point(193, 221);
			this->cmdCancel->Name = L"cmdCancel";
			this->cmdCancel->Size = System::Drawing::Size(75, 23);
			this->cmdCancel->TabIndex = 2;
			this->cmdCancel->Text = L"&Cancel";
			this->cmdCancel->UseVisualStyleBackColor = true;
			// 
			// OptionsForm
			// 
			this->AcceptButton = this->cmdOK;
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->CancelButton = this->cmdCancel;
			this->ClientSize = System::Drawing::Size(280, 256);
			this->Controls->Add(this->cmdCancel);
			this->Controls->Add(this->cmdOK);
			this->Controls->Add(this->propertyGrid1);
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"OptionsForm";
			this->ShowInTaskbar = false;
			this->Text = L"Options";
			this->ResumeLayout(false);

		}
#pragma endregion
	};
}
