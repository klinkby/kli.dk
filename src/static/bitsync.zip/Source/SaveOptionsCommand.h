#pragma once
#include "ICommand.h"
#include "Options.h"

namespace BITSync
{
	using namespace System;
	using namespace System::Runtime::InteropServices;

	ref class SaveOptionsCommand : ICommand {
	private:
		Options^ _options;
	public:
		property Options^ Settings
		{
			Options^ get() {
				return _options;
			}
			void set(Options^ value) {
				_options = value;
			}
		}

		virtual void Execute(SetStatusCallback^ setStatus)
		{
			HKEY hOutKey;
			if (RegCreateKeyExW(HKEY_CURRENT_USER, registryOptionsKey, 
				NULL, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS,
				NULL, &hOutKey, NULL) ==  ERROR_SUCCESS)
			{
				try {
					SetStringValue(hOutKey, L"IncludePattern", _options->IncludePattern);
					SetStringValue(hOutKey, L"ExcludePattern", _options->ExcludePattern);
				}
				finally {
					RegCloseKey(hOutKey);			
				}
			}
		}

		static void SetStringValue(HKEY hKey, LPCWSTR szName, String^ value)
		{
			IntPtr pValue;
			try {
				pValue = Marshal::StringToHGlobalUni(value);
				RegSetValueExW(hKey, szName, NULL, REG_SZ, (PBYTE)pValue.ToPointer(), value->Length*sizeof(L' '));
			}
			finally {
				Marshal::FreeHGlobal(pValue);				
			}
		}
	};
}