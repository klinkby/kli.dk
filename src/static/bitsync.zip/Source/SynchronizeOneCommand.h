#pragma once
#include "ICommand.h"
#include "FileRef.h"
#include "FileSet.h"
#include "Options.h"
#include "BITService.h"

namespace BITSync
{
	using namespace System;
	using namespace System::Windows::Forms;

	ref class SynchronizeOneCommand : ICommand {
	private:
		FileRef^ _fileRef;
		Options^ _options;
	public:
		property FileRef^ File
		{
			FileRef^ get() {
				return _fileRef;
			}
			void set(FileRef^ value) {
				_fileRef = value;
			}
		}
		property Options^ Settings
		{
			Options^ get() {
				return _options;
			}
			void set(Options^ value) {
				_options = value;
			}
		}
		virtual void Execute(SetStatusCallback^ setStatus)
		{
			setStatus("Reading local file structure", 10);
			FileSet^ local = gcnew FileSet(_fileRef->LocalFile, _options->IncludePattern, _options->ExcludePattern);//.Synchronize();
			setStatus("Reading remote file structure", 20);
			FileSet^ remote = gcnew FileSet(_fileRef->RemoteFile, _options->IncludePattern, _options->ExcludePattern);
			setStatus("Ensure directory structure", 50);
			System::Collections::Generic::IList<String^>^ dirs = local->GetDiffDirs(remote);
			CreateDirs(local->BaseDir, dirs);
			setStatus(String::Format("{0} directories created", dirs->Count), 70);
			//me->WriteLog("Ensure file structure...");
			System::Collections::Generic::IList<String^>^ files = local->GetDiffFiles(remote);
			setStatus(String::Format("Downloading {0} files", files->Count), 80);
			if (files->Count > 0)
				CreateDownloadJob(gcnew FileRef(local->BaseDir, remote->BaseDir), files);
			setStatus("Ready", 100);
		}
	private:
		void CreateDirs(String^ basePath, System::Collections::Generic::IEnumerable<String^>^ dirs)
		{
			for each(String^ dir in dirs)
			{
				String^ basedDir = System::IO::Path::Combine(basePath, dir);
				System::IO::Directory::CreateDirectory(basedDir);
			}
		}

		void CreateDownloadJob(FileRef^ basePaths, System::Collections::Generic::IEnumerable<String^>^ files)
		{
			List<FileRef^> filesRefs;
			int i = 0;
			for each(String^ file in files)
			{
				String^ localPath = System::IO::Path::Combine(basePaths->LocalFile, file);
				String^ remotePath = System::IO::Path::Combine(basePaths->RemoteFile, file);
				Uri^ remoteUri = gcnew Uri(gcnew Uri("file://"), gcnew Uri(remotePath));
				filesRefs.Add(gcnew FileRef(localPath, remoteUri->AbsoluteUri));
			}
			BITService bs;
			bs.CreateJob(DateTime::Now.ToString(), filesRefs.ToArray());		 
		}
	};
}