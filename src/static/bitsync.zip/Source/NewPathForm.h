#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


namespace BITSync {

	/// <summary>
	/// Summary for NewPathForm
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class NewPathForm : public System::Windows::Forms::Form
	{
	public:
		NewPathForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~NewPathForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  cmdOK;
	protected: 
	private: System::Windows::Forms::Button^  cmdCancel;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::TextBox^  remotePath;
	private: System::Windows::Forms::Button^  cmdBrowseRemote;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  localPath;
	private: System::Windows::Forms::Button^  cmdBrowseLocal;
	private: System::Windows::Forms::OpenFileDialog^  ofd;
	private: System::Windows::Forms::ErrorProvider^  errorProvider1;
	private: System::ComponentModel::IContainer^  components;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			this->cmdOK = (gcnew System::Windows::Forms::Button());
			this->cmdCancel = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->remotePath = (gcnew System::Windows::Forms::TextBox());
			this->cmdBrowseRemote = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->localPath = (gcnew System::Windows::Forms::TextBox());
			this->cmdBrowseLocal = (gcnew System::Windows::Forms::Button());
			this->ofd = (gcnew System::Windows::Forms::OpenFileDialog());
			this->errorProvider1 = (gcnew System::Windows::Forms::ErrorProvider(this->components));
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->errorProvider1))->BeginInit();
			this->SuspendLayout();
			// 
			// cmdOK
			// 
			this->cmdOK->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Right));
			this->cmdOK->DialogResult = System::Windows::Forms::DialogResult::OK;
			this->cmdOK->Location = System::Drawing::Point(116, 93);
			this->cmdOK->Name = L"cmdOK";
			this->cmdOK->Size = System::Drawing::Size(75, 23);
			this->cmdOK->TabIndex = 0;
			this->cmdOK->Text = L"&OK";
			this->cmdOK->UseVisualStyleBackColor = true;
			// 
			// cmdCancel
			// 
			this->cmdCancel->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Right));
			this->cmdCancel->CausesValidation = false;
			this->cmdCancel->DialogResult = System::Windows::Forms::DialogResult::Cancel;
			this->cmdCancel->Location = System::Drawing::Point(197, 93);
			this->cmdCancel->Name = L"cmdCancel";
			this->cmdCancel->Size = System::Drawing::Size(75, 23);
			this->cmdCancel->TabIndex = 1;
			this->cmdCancel->Text = L"&Cancel";
			this->cmdCancel->UseVisualStyleBackColor = true;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(12, 9);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(72, 13);
			this->label1->TabIndex = 2;
			this->label1->Text = L"&Remote Path:";
			// 
			// remotePath
			// 
			this->remotePath->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->remotePath->Location = System::Drawing::Point(12, 25);
			this->remotePath->Name = L"remotePath";
			this->remotePath->Size = System::Drawing::Size(213, 20);
			this->remotePath->TabIndex = 3;
			this->remotePath->Validating += gcnew System::ComponentModel::CancelEventHandler(this, &NewPathForm::remotePath_Validating);
			// 
			// cmdBrowseRemote
			// 
			this->cmdBrowseRemote->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->cmdBrowseRemote->CausesValidation = false;
			this->cmdBrowseRemote->Location = System::Drawing::Point(244, 23);
			this->cmdBrowseRemote->Name = L"cmdBrowseRemote";
			this->cmdBrowseRemote->Size = System::Drawing::Size(28, 23);
			this->cmdBrowseRemote->TabIndex = 4;
			this->cmdBrowseRemote->Text = L"...";
			this->cmdBrowseRemote->UseVisualStyleBackColor = true;
			this->cmdBrowseRemote->Click += gcnew System::EventHandler(this, &NewPathForm::cmdBrowseRemote_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(12, 48);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(61, 13);
			this->label2->TabIndex = 2;
			this->label2->Text = L"&Local Path:";
			// 
			// localPath
			// 
			this->localPath->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->localPath->Location = System::Drawing::Point(12, 64);
			this->localPath->Name = L"localPath";
			this->localPath->Size = System::Drawing::Size(213, 20);
			this->localPath->TabIndex = 3;
			this->localPath->Validating += gcnew System::ComponentModel::CancelEventHandler(this, &NewPathForm::localPath_Validating);
			// 
			// cmdBrowseLocal
			// 
			this->cmdBrowseLocal->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->cmdBrowseLocal->CausesValidation = false;
			this->cmdBrowseLocal->Location = System::Drawing::Point(244, 62);
			this->cmdBrowseLocal->Name = L"cmdBrowseLocal";
			this->cmdBrowseLocal->Size = System::Drawing::Size(28, 23);
			this->cmdBrowseLocal->TabIndex = 4;
			this->cmdBrowseLocal->Text = L"...";
			this->cmdBrowseLocal->UseVisualStyleBackColor = true;
			this->cmdBrowseLocal->Click += gcnew System::EventHandler(this, &NewPathForm::cmdBrowseLocal_Click);
			// 
			// ofd
			// 
			this->ofd->CheckFileExists = false;
			this->ofd->CheckPathExists = false;
			// 
			// errorProvider1
			// 
			this->errorProvider1->ContainerControl = this;
			// 
			// NewPathForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 128);
			this->Controls->Add(this->cmdBrowseLocal);
			this->Controls->Add(this->cmdBrowseRemote);
			this->Controls->Add(this->localPath);
			this->Controls->Add(this->remotePath);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->cmdCancel);
			this->Controls->Add(this->cmdOK);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog;
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"NewPathForm";
			this->ShowInTaskbar = false;
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterParent;
			this->Text = L"New Path";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->errorProvider1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
		public:
			property String^ RemotePath	{
				String^ get() {
					return remotePath->Text;
				}
				void set(String^ value) {
					remotePath->Text = value;
				}
			}
			property String^ LocalPath	{
				String^ get() {
					return localPath->Text;
				}
				void set(String^ value) {
					localPath->Text = value;
				}
			}
	private: System::Void cmdBrowseRemote_Click(System::Object^  sender, System::EventArgs^  e) {
				 if (ofd->ShowDialog(this) == System::Windows::Forms::DialogResult::OK)
				 {
					 remotePath->Text = ofd->FileName;
				 }
			 }
	private: System::Void cmdBrowseLocal_Click(System::Object^  sender, System::EventArgs^  e) {
				 if (ofd->ShowDialog(this) == System::Windows::Forms::DialogResult::OK)
				 {
					 localPath->Text = ofd->FileName;
				 }

		 }
private: System::Void remotePath_Validating(System::Object^  sender, System::ComponentModel::CancelEventArgs^  e) {
			 e->Cancel = (!(System::IO::Directory::Exists(remotePath->Text) 
				 || System::IO::File::Exists(remotePath->Text)));
			 
			 if (e->Cancel)
				 errorProvider1->SetError(remotePath, L"The path does not exist");
			 else
				errorProvider1->SetError(remotePath, nullptr);
		 }
private: System::Void localPath_Validating(System::Object^  sender, System::ComponentModel::CancelEventArgs^  e) {
			 e->Cancel =  (!(System::IO::Directory::Exists(localPath->Text) 
				 || System::IO::File::Exists(localPath->Text)));
			 if (e->Cancel)
				 errorProvider1->SetError(localPath, L"The path does not exist");
			 else
				errorProvider1->SetError(localPath, nullptr);
		 }

};
}
